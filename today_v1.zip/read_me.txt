Written in QB6

4

The program will display the event of the day. In the case of multiple events for the same date, the program will choose 1 at random.

The program classifies it's events into 6 categories that may be filtered to you liking. The program ships with default events for all days. 

In the settings menu, you may add your own events. Default events and user added events will always display regardless of filters applied. 

In addition to the ability to add your own events, the program can also install data paks for specific categories of events. These include famous Birthdays, Social Science, Religious, Natural, Scientific and War events. User filters in the settimgs allow you to customize the data displayed. Filters applied in the "today" program also apply to the "todaysa" mini 
"today" program. The program has built in features to clean up after itself.

The birthday events do not include notorious criminals (though some are interesting historically). There will be an add on pak for those who wish to include these entries.  

The default data contains 4 general events for every day of the year (including leap years). 

Several add on paks are available at this time. It takes a lot of time to write a data pak. More data paks may be released over time.



today.exe (main program, program settings, add custom events)


todaysa.exe (stand alone that just displays the daily events for use in start up or timer routines)


history.dat (stored history data)


sfx_0069.mp3 (sfx for program)


install.log (keeps track of installed paks)


read_me.txt (this file)
